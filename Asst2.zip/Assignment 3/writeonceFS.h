#include <stdint.h>
#include <stddef.h>
#define wo_name_len 16
#define wo_max_files 128
#define wo_open_max 32
#define BLOCK_SIZE 1024
int wo_mount(const char *diskname);
int wo_umount(void);
int wo_create(const char *name_of_file);
int wo_delete(const char *name_of_file);
int wo_open(const char *name_of_file);
int wo_close(int fd);
int wo_stat(int fd);
int wo_lseek(int fd, size_t offset);
int wo_write(int fd, void *buf, size_t count);
int wo_read(int fd, void *buf, size_t count);
int create_block_disk(const char *diskname, size_t bcount);
int block_disk_open(const char *diskname);
int close_block_disk(void);
int block_disk_nos(void);
int write_block(size_t block, const void *buf);
int read_block(size_t block, void *buf);