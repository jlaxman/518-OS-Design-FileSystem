#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include "writeonceFS.h"
#include "sys/types.h"
#include "sys/stat.h"
#include "fcntl.h"
#define wo_error(fmt, ...) \
	fprintf(stderr, "%s: ERROR-"fmt"\n", __func__, ##__VA_ARGS__)

#define EOC 0xFFFF
#define EMPTY 0

#define error_block(fmt, ...) \
	fprintf(stderr, "%s: "fmt"\n", __func__, ##__VA_ARGS__)

#define BAD_FD -1

struct disk {
	int fd;
	size_t byte_count;
};
static struct disk disk = { .fd = BAD_FD };

int create_block_disk(const char *diskname, size_t byte_count)
{
	int fd;
	if (!diskname) {
		error_block("invalid file diskname");
		return -1;
	}
	if ((fd = open(diskname, O_WRONLY | O_CREAT | O_TRUNC, 0644)) < 0) {
		perror("open");
		return -1;
	}
	if (ftruncate(fd, byte_count * BLOCK_SIZE) < 0) {
		perror("ftruncate");
		return -1;
	}

	close(fd);

	return 0;
}

int block_disk_open(const char *diskname)
{
	int fd;
	struct stat st;
	if (!diskname) {
		error_block("invalid file diskname");
		return -1;
	}

	if (disk.fd != BAD_FD) {
		error_block("disk already open");
		return -1;
	}

	if ((fd = open(diskname, O_RDWR, 0644)) < 0) {
		perror("open");
		return -1;
	}

	if (fstat(fd, &st)) {
		perror("file_stat");
		return -1;
	}

	if (st.st_size % BLOCK_SIZE != 0) {
		error_block("size '%zu' is not multiple of '%d'",
			    st.st_size, BLOCK_SIZE);
		return -1;
	}

	disk.fd = fd;
	disk.byte_count = st.st_size / BLOCK_SIZE;

	return 0;
}

int close_block_disk(void)
{
	if (disk.fd == BAD_FD) {
		error_block("no disk currently open");
		return -1;
	}

	close(disk.fd);

	disk.fd = BAD_FD;

	return 0;
}

int block_disk_nos(void)
{
	if (disk.fd == BAD_FD) {
		error_block("no disk currently open");
		return -1;
	}

	return disk.byte_count;
}

int write_block(size_t block, const void *buf)
{
	if (disk.fd == BAD_FD) {
		error_block("no disk currently open");
		return -1;
	}

	if (block >= disk.byte_count) {
		error_block("block index out of bounds (%zu/%zu)",
			    block, disk.byte_count);
		return -1;
	}

	if (lseek(disk.fd, block * BLOCK_SIZE, SEEK_SET) < 0) {
		perror("lseek");
		return -1;
	}

	if (write(disk.fd, buf, BLOCK_SIZE) < 0) {
		perror("write");
		return -1;
	}

	return 0;
}

int read_block(size_t block, void *buf)
{
	if (disk.fd == BAD_FD) {
		error_block("no disk currently open");
		return -1;
	}

	if (block >= disk.byte_count) {
		error_block("block index out of bounds (%zu/%zu)",
			    block, disk.byte_count);
		return -1;
	}

	if (lseek(disk.fd, block * BLOCK_SIZE, SEEK_SET) < 0) {
		perror("lseek");
		return -1;
	}

	if (read(disk.fd, buf, BLOCK_SIZE) < 0) {
		perror("write");
		return -1;
	}

	return 0;
}

typedef enum { false, true } bool;
struct wo_superblock {
    char     signature[8];
    uint16_t num_of_block;
    uint16_t root_index;
    uint16_t data_start;
    uint16_t no_of_data_blocks;
    uint8_t  num_FAT_blocks; 
    uint8_t  avail[4079];
} __attribute__((packed));
struct FAT_t {
	uint16_t wo_words;
};
struct rootdirectory_t {
	char     name_of_file[wo_name_len];
	uint32_t fsize;
	uint16_t start_data_block;
	uint8_t  avail[10];
} __attribute__((packed));
struct file_descriptor_t {
    bool   is_used;       
    int    file_index;              
    size_t offset;  
	char   file_name[wo_name_len];
};
struct wo_superblock     *superblock;
struct rootdirectory_t   *root_dir_block;
struct FAT_t             *FAT_blocks;
struct file_descriptor_t fd_table[wo_open_max]; 
static bool error_free(const char *name_of_file);
static int  file_location(const char* file_name);
static bool is_open(const char* file_name);
static int  locate_avail_fd();
static int  get_num_FAT_free_blocks();
static int  go_to_cur_FAT_block(int cur_fat_index, int iter_amount);
int wo_mount(const char *diskname) {
	superblock = malloc(BLOCK_SIZE);
	if(block_disk_open(diskname) < 0){
		wo_error("failure to open virtual disk \n");
		return -1;
	}
	if(read_block(0, (void*)superblock) < 0){
		wo_error( "failure to read from block \n");
		return -1;
	}
	if(strncmp(superblock->signature, "CS518ROS", 8) != 0){
		wo_error( "invalid disk signature \n");
		return -1;
	}
	if(superblock->num_of_block != block_disk_nos()) {
		wo_error("incorrect block disk count \n");
		return -1;
	}
	FAT_blocks = malloc(superblock->num_FAT_blocks * BLOCK_SIZE);
	for(int i = 0; i < superblock->num_FAT_blocks; i++) {
		if(read_block(i + 1, (void*)FAT_blocks + (i * BLOCK_SIZE)) < 0) {
			wo_error("failure to read from block \n");
			return -1;
		}
	}
	root_dir_block = malloc(sizeof(struct rootdirectory_t) * wo_max_files);
	if(read_block(superblock->num_FAT_blocks + 1, (void*)root_dir_block) < 0) { 
		wo_error("failure to read from block \n");
		return -1;
	}
    for(int i = 0; i < wo_open_max; i++) {
		fd_table[i].is_used = false;
	}
        
	return 0;
}
int wo_umount(void) {

	if(!superblock){
		wo_error("No disk available to unmount\n");
		return -1;
	}
	if(write_block(0, (void*)superblock) < 0) {
		wo_error("failure to write to block \n");
		return -1;
	}
	for(int i = 0; i < superblock->num_FAT_blocks; i++) {
		if(write_block(i + 1, (void*)FAT_blocks + (i * BLOCK_SIZE)) < 0) {
			wo_error("failure to write to block \n");
			return -1;
		}
	}
	if(write_block(superblock->num_FAT_blocks + 1, (void*)root_dir_block) < 0) {
		wo_error("failure to write to block \n");
			return -1;
	}
	free(superblock);
	free(root_dir_block);
	free(FAT_blocks);
    for(int i = 0; i < wo_open_max; i++) {
		fd_table[i].offset = 0;
		fd_table[i].is_used = false;
		fd_table[i].file_index = -1;
		memset(fd_table[i].file_name, 0, wo_name_len);
    }
	close_block_disk();
	return 0;
}
int wo_create(const char *name_of_file) {

	if(error_free(name_of_file) == false) {
		wo_error("error associated with name of file");
		return -1;
	}
	for(int i = 0; i < wo_max_files; i++) {
		if(root_dir_block[i].name_of_file[0] == EMPTY) {	

			// initialize file data 
			strcpy(root_dir_block[i].name_of_file, name_of_file);
			root_dir_block[i].fsize     = 0;
			root_dir_block[i].start_data_block = EOC;

			return 0;
		}
	}
	return -1;
}
int wo_delete(const char *name_of_file) {
	
	if (is_open(name_of_file)) {
		wo_error("file currently open");
		return -1;
	}

	int file_index = file_location(name_of_file);
	struct rootdirectory_t* the_dir = &root_dir_block[file_index]; 
	int frst_dta_blk_i = the_dir->start_data_block;

	while (frst_dta_blk_i != EOC) {
		uint16_t tmp = FAT_blocks[frst_dta_blk_i].wo_words;
		FAT_blocks[frst_dta_blk_i].wo_words = EMPTY;
		frst_dta_blk_i = tmp;
	}
	memset(the_dir->name_of_file, 0, wo_name_len);
	the_dir->fsize = 0;

	return 0;
}
int wo_open(const char *name_of_file) {

    int file_index = file_location(name_of_file);
    if(file_index == -1) { 
        wo_error("file @[%s] doesnt exist\n", name_of_file);
        return -1;
    } 

    int fd = locate_avail_fd();
    if (fd == -1){
		wo_error("max file descriptors already allocated\n");
        return -1;
    }

	fd_table[fd].is_used    = true;
	fd_table[fd].file_index = file_index;
	fd_table[fd].offset     = 0;
	
	strcpy(fd_table[fd].file_name, name_of_file); 

    return fd;
}
int wo_close(int fd) {

    if(fd >= wo_open_max || fd < 0 || fd_table[fd].is_used == 0) {
		wo_error("invalid file descriptor supplied \n");
        return -1;
    }

    struct file_descriptor_t *fd_obj = &fd_table[fd];

    int file_index = file_location(fd_obj->file_name);
    if(file_index == -1) { 
        wo_error("file @[%s] doesnt exist\n", fd_obj->file_name);
        return -1;
    } 

    fd_obj->is_used = false;

	return 0;
}
int wo_stat(int fd) {
    if(fd >= wo_open_max || fd < 0 || fd_table[fd].is_used == false) {
		wo_error("invalid file descriptor supplied \n");
        return -1;
    }

    struct file_descriptor_t *fd_obj = &fd_table[fd];

    int file_index = file_location(fd_obj->file_name);
    if(file_index == -1) { 
        wo_error("file @[%s] doesnt exist\n", fd_obj->file_name);
        return -1;
    } 

	return root_dir_block[file_index].fsize;
}
int wo_lseek(int fd, size_t offset) {
	struct file_descriptor_t *fd_obj = &fd_table[fd];
    int file_index = file_location(fd_obj->file_name);
    if(file_index == -1) { 
        wo_error("file @[%s] doesnt exist\n", fd_obj->file_name);
        return -1;
    } 

	int32_t fsize = wo_stat(fd);
	
	if (offset < 0 || offset > fsize) {
        wo_error("file @[%s] is out of bounds \n", fd_obj->file_name);
        return -1;
	} else if (fd_table[fd].is_used == false) {
        wo_error("invalid file descriptor [%s] \n", fd_obj->file_name);
        return -1;
	} 

	fd_table[fd].offset = offset;
	return 0;
}

int wo_write(int fd, void *buf, size_t count) {
	if (count <= 0) {
        wo_error("request nbytes amount is trivial" );
        return -1;
	} else if (fd <= -1 || fd >= wo_open_max) {
        wo_error("invalid file descriptor [%d] \n", fd);
        return -1;
	} else if (get_num_FAT_free_blocks() == EMPTY) {
        wo_error("no free entries to write to");
        return -1;
	} else if (fd_table[fd].is_used == false) {
        wo_error("file descriptor is not open");
        return -1;
	}
	char *file_name = fd_table[fd].file_name;				
	int file_index = file_location(file_name);				
	int offset = fd_table[fd].offset;						

	struct rootdirectory_t *the_dir = &root_dir_block[file_index];	

	int num_of_block = ((count + (offset % BLOCK_SIZE)) / BLOCK_SIZE) + 1; 
	int cur_block = offset/BLOCK_SIZE;					
	int curr_fat_index = the_dir->start_data_block;
 	int extra_blocks;
 	if(the_dir->fsize != 0) {
		int file_width = the_dir->fsize / BLOCK_SIZE;
		int block_difference = offset + num_of_block * BLOCK_SIZE;
		extra_blocks = (block_difference / BLOCK_SIZE) - 1;
		extra_blocks = extra_blocks - file_width;
	}
	else extra_blocks = num_of_block;
	char *write_buf = (char*)buf;
	char bounce_buff[BLOCK_SIZE];
	
	int amount_to_write = count;
	int left_shift;
	int total_byte_written = 0;
	int location = offset % BLOCK_SIZE;
	curr_fat_index = go_to_cur_FAT_block(curr_fat_index, cur_block);

	int available_data_blocks = 0;
	int fat_block_indices[extra_blocks];
	for(int j = 0; j < superblock->no_of_data_blocks; j++){
		if(FAT_blocks[j].wo_words == 0){
			fat_block_indices[available_data_blocks] = j;
			available_data_blocks++;
		}
		if(available_data_blocks == extra_blocks)
			break;
	}
	num_of_block = available_data_blocks; 
	if(the_dir->start_data_block == EOC) { 
		curr_fat_index = fat_block_indices[0];
		the_dir->start_data_block = curr_fat_index;
	}
	else {
		int frst_dta_blk_i = the_dir->start_data_block;
		while(frst_dta_blk_i != EOC){
			frst_dta_blk_i = FAT_blocks[frst_dta_blk_i].wo_words;
		}
		for(int k =0; k < num_of_block; k++){
			FAT_blocks[frst_dta_blk_i].wo_words = fat_block_indices[k];
			frst_dta_blk_i = FAT_blocks[frst_dta_blk_i].wo_words;
		}
		FAT_blocks[frst_dta_blk_i].wo_words = EOC;
	}

	num_of_block = ((count + (offset % BLOCK_SIZE)) / BLOCK_SIZE) + 1;
	int num_free = get_num_FAT_free_blocks();
	if (num_of_block > num_free) {
		num_of_block = num_free;
	}
	for (int i = 0; i < num_of_block; i++) {
		if (location + amount_to_write > BLOCK_SIZE) {
			left_shift = BLOCK_SIZE - location;
		} else {
			left_shift = amount_to_write;
		}

		memcpy(bounce_buff + location, write_buf, left_shift);
		write_block(curr_fat_index + superblock->data_start, (void*)bounce_buff);
		total_byte_written += left_shift;
		write_buf += left_shift;

		location= 0;
		amount_to_write -= left_shift;
		if(i < num_of_block - 1){
			FAT_blocks[curr_fat_index].wo_words = fat_block_indices[i+1];
			curr_fat_index = FAT_blocks[curr_fat_index].wo_words;
		}
		else{
			FAT_blocks[curr_fat_index].wo_words = EOC;
			curr_fat_index = FAT_blocks[curr_fat_index].wo_words;
		}
	}
	if(offset + total_byte_written > the_dir->fsize){
		the_dir->fsize = offset + total_byte_written;
	}

	fd_table[fd].offset += total_byte_written;
	return total_byte_written;
}
int wo_read(int fd, void *buf, size_t count) {
	
	// error check 
    if(fd_table[fd].is_used == false || 
	   fd >= wo_open_max) {
		wo_error("invalid file descriptor [%d]", fd);
        return -1;
    } else if (count <= 0) {
		wo_error("request nbyte amount is trivial");
		return -1;
	}  
	char *file_name = fd_table[fd].file_name;
	int file_index = file_location(file_name);
	size_t offset = fd_table[fd].offset;
	
	struct rootdirectory_t *the_dir = &root_dir_block[file_index];
	int amount_to_read = 0;
	if (offset + count > the_dir->fsize) 
		amount_to_read = abs(the_dir->fsize - offset);
	else amount_to_read = count;

	char *read_buf = (char *)buf;
	int16_t FAT_iter = the_dir->start_data_block;
	size_t num_of_block = (amount_to_read / BLOCK_SIZE) + 1;
	int cur_block = offset / BLOCK_SIZE; 
	int location= offset % BLOCK_SIZE;
	char bounce_buff[BLOCK_SIZE];
	FAT_iter = go_to_cur_FAT_block(FAT_iter, cur_block);
	int left_shift = 0;
	int total_bytes_read = 0;
	for (int i = 0; i < num_of_block; i++) {
		if (location+ amount_to_read > BLOCK_SIZE) {
			left_shift = BLOCK_SIZE - location;
		} else {
			left_shift = amount_to_read;
		}
		read_block(FAT_iter + superblock->data_start, (void*)bounce_buff);
		memcpy(read_buf, bounce_buff + location, left_shift);
		total_bytes_read += left_shift;
		read_buf += left_shift;
		location= 0;
		FAT_iter = FAT_blocks[FAT_iter].wo_words;
		amount_to_read -= left_shift;
	}

	fd_table[fd].offset += total_bytes_read;
	return total_bytes_read;
}
static int file_location(const char* file_name) {
	int i;
    for(i = 0; i < wo_max_files; i++) 
        if(strncmp(root_dir_block[i].name_of_file, file_name, wo_name_len) == 0 &&  
			      root_dir_block[i].name_of_file != EMPTY) 
            return i;  
    return -1;      
}
static int locate_avail_fd() {
	int i;
	for(i = 0; i < wo_open_max; i++) 
        if(fd_table[i].is_used == false) 
			return i; 
    return -1;
}
static bool error_free(const char *name_of_file){
	int size = strlen(name_of_file);
	if(size > wo_name_len){
		wo_error("File name is longer than wo_max_files\n");
		return false;
	}
	int same_char = 0;
	int files_in_rootdir = 0;
	for(int i = 0; i < wo_max_files; i++){
		for(int j = 0; j < size; j ++){
			if(root_dir_block[i].name_of_file[j] == name_of_file[j])
				same_char++;
		}
		if(root_dir_block[i].name_of_file[0] != EMPTY)
			files_in_rootdir++;
	}
	if(same_char == size){
		wo_error("file @[%s] already exists\n", name_of_file);
		return false;
	}
	if(files_in_rootdir == wo_max_files){
		wo_error("All files in rootdirectory are taken\n");
		return false;
	}
		
	return true;
}

static bool is_open(const char* name_of_file)
{
	int file_index = file_location(name_of_file);

	if (file_index == -1) {
		wo_error("file @[%s] doesnt exist\n", name_of_file);
        return true;
	}

	struct rootdirectory_t* the_dir = &root_dir_block[file_index]; 
	for(int i = 0; i < wo_open_max; i++) {
		if(strncmp(the_dir->name_of_file, fd_table[i].file_name, wo_name_len) == 0 
		   && fd_table[i].is_used) {
			wo_error("cannot remove file @[%s] as it is currently open\n", name_of_file);
			return true;
		}
	}

	return false;
}

static int get_num_FAT_free_blocks()
{
	int count = 0;
	for (int i = 1; i < superblock->no_of_data_blocks; i++) {
		if (FAT_blocks[i].wo_words == EMPTY) count++;
	}
	return count;
}
 
static int go_to_cur_FAT_block(int cur_fat_index, int iter_amount)
{
	for (int i = 0; i < iter_amount; i++) {
		if (cur_fat_index == EOC) {
			wo_error("attempted to exceed end of file chain");
			return -1;
		}
		cur_fat_index = FAT_blocks[cur_fat_index].wo_words;
	}
	return cur_fat_index;
}
